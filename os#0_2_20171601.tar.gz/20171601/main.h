#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "list.c"
#include "hash.c"
#include "bitmap.c"
